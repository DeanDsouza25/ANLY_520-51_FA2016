'''
Created on Nov 29, 2016

@author: demon
'''

nfile = open('C:/Users/demon/OneDrive/Documents/GitHub/ANLY_520-51_FA2016/FinalProject/data/AllAuthors.txt','r')
dfile = open('C:/Users/demon/OneDrive/Documents/GitHub/ANLY_520-51_FA2016/FinalProject/data/AllText.txt','r')

for author in nfile:
    print author
    
#for line in dfile:
#    print line

nfile.close()
dfile.close()